<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('certificate_templates', function (Blueprint $table) {
        $table->id();

        $table->string('name'); // Template Name

        $table->string('ou')->nullable();
        $table->string('organization')->nullable();
        $table->string('locality')->nullable();
        $table->string('state')->nullable();
        $table->string('country', 5)->nullable();
        $table->string('email')->nullable();

        $table->timestamps();
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('certificate_templates');
    }
};
