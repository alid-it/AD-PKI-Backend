<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement('ALTER TABLE certificates ALTER COLUMN serial_number DROP NOT NULL');
        DB::statement('ALTER TABLE certificates ALTER COLUMN valid_from DROP NOT NULL');
        DB::statement('ALTER TABLE certificates ALTER COLUMN valid_to DROP NOT NULL');
        DB::statement('ALTER TABLE certificates ALTER COLUMN crt_path DROP NOT NULL');
        DB::statement('ALTER TABLE certificates ALTER COLUMN key_path DROP NOT NULL');
        DB::statement('ALTER TABLE certificates ALTER COLUMN chain_path DROP NOT NULL');
    }

    public function down(): void
    {
        DB::statement('ALTER TABLE certificates ALTER COLUMN serial_number SET NOT NULL');
        DB::statement('ALTER TABLE certificates ALTER COLUMN valid_from SET NOT NULL');
        DB::statement('ALTER TABLE certificates ALTER COLUMN valid_to SET NOT NULL');
        DB::statement('ALTER TABLE certificates ALTER COLUMN crt_path SET NOT NULL');

        // key_path und chain_path würde ich im Down nicht zwingend wieder NOT NULL setzen,
        // weil manche Zertifikate eventuell keinen Key speichern.
    }
};