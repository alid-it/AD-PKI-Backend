<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('certificates', function (Blueprint $table) {
            $table->id();

            $table->string('type'); // root, intermediate, tls, client, codesign
            $table->string('common_name');
            $table->text('san')->nullable();

            $table->string('serial_number')->unique();

            $table->timestamp('valid_from');
            $table->timestamp('valid_to');

            $table->foreignId('parent_id')->nullable()->constrained('certificates')->nullOnDelete();

            $table->boolean('is_acme')->default(false);

            // File paths (wichtig!)
            $table->string('crt_path');
            $table->string('key_path')->nullable();
            $table->string('chain_path')->nullable();
            $table->string('crl_path')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('certificates');
    }
};
