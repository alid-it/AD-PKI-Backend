<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('notification_events', function (Blueprint $table) {
            $table->id();

            $table->string('event')->unique();
            $table->boolean('enabled')->default(true);

            $table->boolean('mail')->default(true);
            $table->boolean('webhook')->default(true);
            $table->boolean('telegram')->default(true);

            $table->text('title_template')->nullable();
            $table->text('message_template')->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('notification_events');
    }
};
